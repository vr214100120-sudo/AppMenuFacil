package com.example.appmenufacil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appmenufacil.ui.theme.APPMENUFACILTheme
import java.util.Locale
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale

data class MenuItem(
    val name: String,
    val price: Double
)

data class CartItem(
    val item: MenuItem,
    val quantity: Int
)

data class Order(
    val customerName: String,
    val tableNumber: String,
    val items: List<CartItem>,
    val total: Double
)

val menuList = listOf(
    MenuItem("POLLO FRITO", 3.50),
    MenuItem("CARNE ASADA", 6.00),
    MenuItem("PIZZA", 4.50),
    MenuItem("BURRITO", 2.00),
    MenuItem("HAMBURGUESA", 4.00),
    MenuItem("TACOS", 3.50),
    MenuItem("SODA", 1.00),
    MenuItem("JUGO NATURAL", 1.25)
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {

            APPMENUFACILTheme {

                var currentScreen by remember {
                    mutableStateOf(1)
                }

                val cartItems = remember {
                    mutableStateListOf<CartItem>()
                }

                val orders = remember {
                    mutableStateListOf<Order>()
                }

                var customerName by remember {
                    mutableStateOf("")
                }

                var tableNumber by remember {
                    mutableStateOf("")
                }

                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {

                    when (currentScreen) {

                        1 -> LoginScreen(
                            onClientClick = {
                                currentScreen = 2
                            },

                            onEmployeeClick = {
                                currentScreen = 5
                            }
                        )

                        2 -> ClientInfoScreen(
                            customerName = customerName,
                            tableNumber = tableNumber,

                            onNameChange = {
                                customerName = it
                            },

                            onTableChange = {
                                tableNumber = it
                            },

                            onBack = {
                                currentScreen = 1
                            },

                            onContinue = {
                                currentScreen = 3
                            }
                        )

                        3 -> ClientMenuScreen(
                            onBack = {
                                currentScreen = 2
                            },

                            onGoToCart = {
                                currentScreen = 4
                            },

                            onAddToCart = { item ->

                                val index =
                                    cartItems.indexOfFirst {
                                        it.item.name == item.name
                                    }

                                if (index != -1) {

                                    cartItems[index] =
                                        cartItems[index].copy(
                                            quantity =
                                                cartItems[index].quantity + 1
                                        )

                                } else {

                                    cartItems.add(
                                        CartItem(item, 1)
                                    )
                                }
                            }
                        )
                        4 -> ClientCartScreen(
                            cartItems = cartItems,
                            customerName = customerName,
                            tableNumber = tableNumber,

                            onBack = {
                                currentScreen = 3
                            },

                            onUpdateQuantity = { item, delta ->

                                val index =
                                    cartItems.indexOfFirst {
                                        it.item.name == item.name
                                    }

                                if (index != -1) {

                                    val newQty =
                                        cartItems[index].quantity + delta

                                    if (newQty > 0) {

                                        cartItems[index] =
                                            cartItems[index].copy(
                                                quantity = newQty
                                            )

                                    } else {

                                        cartItems.removeAt(index)
                                    }
                                }
                            },

                            onOrder = {

                                val total =
                                    cartItems.sumOf {
                                        it.item.price * it.quantity
                                    }

                                orders.add(
                                    Order(
                                        customerName = customerName,
                                        tableNumber = tableNumber,
                                        items = cartItems.toList(),
                                        total = total
                                    )
                                )

                                cartItems.clear()
                            }
                        )

                        5 -> ActiveOrdersScreen(
                            orders = orders,

                            onDeleteOrder = { order ->
                                orders.remove(order)
                            },

                            onLogout = {
                                currentScreen = 1

                            }
                        )
                    }
                }
            }
        }
    }
}

// ================= LOGIN =================

@Composable
fun LoginScreen(
    onClientClick: () -> Unit,
    onEmployeeClick: () -> Unit
) {

    val colors = listOf(
        Color(0xFF6D3311),
        Color(0xFFF9B057),
        Color(0xFFF7C284),
        Color(0xFF4DB69E)
    )

    var email by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var showRecoveryMessage by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors[0])
            .padding(16.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(48.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(
                    colors[1],
                    RoundedCornerShape(32.dp)
                ),

            contentAlignment = Alignment.Center
        ) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                Image(
                    painter = painterResource(id = R.drawable.imagen_2003),
                    contentDescription = "Logo",
                    modifier = Modifier.size(150.dp),
                    contentScale = ContentScale.Fit
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    "MENÚ FACIL",
                    fontSize = 48.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF3E2723)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(2.8f)
                .background(
                    colors[2],
                    RoundedCornerShape(
                        topStart = 48.dp,
                        topEnd = 48.dp,
                        bottomStart = 32.dp,
                        bottomEnd = 32.dp
                    )
                )
                .padding(24.dp),

            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {

            Text(
                "BIENVENIDO",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Button(
                onClick = onClientClick,

                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),

                colors = ButtonDefaults.buttonColors(
                    containerColor = colors[3]
                ),

                shape = RoundedCornerShape(25.dp)
            ) {

                Text(
                    "SOY CLIENTE",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    "SOY EMPLEADO",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Text(
                    "INGRESE CREDENCIALES",
                    fontSize = 12.sp,
                    color = Color.Black
                )
            }
            TextField(
                value = email,

                onValueChange = {
                    email = it
                },

                placeholder = {
                    Text("INGRESA EMAIL")
                },

                modifier = Modifier.fillMaxWidth(),

                shape = RoundedCornerShape(27.dp),

                singleLine = true
            )

            TextField(
                value = password,

                onValueChange = {
                    password = it
                },

                placeholder = {
                    Text("CONTRASEÑA")
                },

                modifier = Modifier.fillMaxWidth(),

                shape = RoundedCornerShape(27.dp),

                visualTransformation = PasswordVisualTransformation(),

                trailingIcon = {

                    Icon(
                        Icons.Default.Visibility,
                        contentDescription = null
                    )
                },

                singleLine = true
            )

            if (errorMessage.isNotEmpty()) {

                Text(
                    text = errorMessage,
                    color = Color.Red,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = {

                    if (
                        email == "Jorgevaliente@gmail.com" &&
                        password == "1234"
                    ) {

                        errorMessage = ""

                        onEmployeeClick()

                    } else {

                        errorMessage =
                            "Correo o contraseña incorrectos"
                    }
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),

                colors = ButtonDefaults.buttonColors(
                    containerColor = colors[3]
                ),

                shape = RoundedCornerShape(25.dp)
            ) {

                Text(
                    "CONTINUAR",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }

            TextButton(
                onClick = {
                    showRecoveryMessage = true
                }
            ) {

                Text(
                    "¿OLVIDASTE LA CONTRA?...",
                    color = Color.Black,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (showRecoveryMessage) {

                Text(
                    text =
                        "Ponte en contacto con Serviciotecnico1234@gmail.com",

                    color = Color.Black,

                    fontWeight = FontWeight.Bold,

                    fontSize = 12.sp
                )
            }
        }
    }
}

// ================= DATOS CLIENTE =================

@Composable
fun ClientInfoScreen(
    customerName: String,
    tableNumber: String,
    onNameChange: (String) -> Unit,
    onTableChange: (String) -> Unit,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {

    val colors = listOf(
        Color(0xFF6D3311),
        Color(0xFFF7C284),
        Color(0xFF4DB69E)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors[0])
            .padding(16.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(48.dp))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    colors[1],
                    RoundedCornerShape(32.dp)
                )
                .padding(24.dp),

            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {

            Text(
                "BIENVENIDO",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF3E2723)
            )

            Box(
                modifier = Modifier
                    .size(130.dp)
                    .background(
                        Color(0xFFFFE0B2),
                        CircleShape
                    ),

                contentAlignment = Alignment.Center
            ) {

                Text(
                    "🍪",
                    fontSize = 75.sp
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    "SU NOMBRE",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                TextField(
                    value = customerName,

                    onValueChange = {

                        if (
                            it.all { char ->
                                char.isLetter() ||
                                        char.isWhitespace()
                            }
                        ) {

                            onNameChange(it)
                        }
                    },

                    modifier = Modifier.fillMaxWidth(),

                    placeholder = {
                        Text("NOMBRE")
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    "NUMERO DE MESA",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                TextField(
                    value = tableNumber,

                    onValueChange = {

                        if (
                            it.all { char ->
                                char.isDigit()
                            }
                        ) {

                            onTableChange(it)
                        }
                    },

                    modifier = Modifier.fillMaxWidth(),

                    placeholder = {
                        Text("MESA")
                    }
                )
            }
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {

                Button(
                    onClick = onContinue,

                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors[2]
                    ),

                    shape = RoundedCornerShape(27.dp)
                ) {

                    Text(
                        "CONTINUAR",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onBack,

                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors[2]
                    ),

                    shape = RoundedCornerShape(27.dp)
                ) {

                    Text(
                        "REGRESAR A INICIO",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ================= MENU =================

@Composable
fun ClientMenuScreen(
    onBack: () -> Unit,
    onGoToCart: () -> Unit,
    onAddToCart: (MenuItem) -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFBF541F))
            .padding(16.dp)
            .statusBarsPadding(),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            "MENÚ",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(20.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),

            modifier = Modifier.weight(1f),

            horizontalArrangement = Arrangement.spacedBy(16.dp),

            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            items(menuList) { item ->

                MenuCardVisual(
                    item.name,

                    "$ ${
                        String.format(
                            Locale.US,
                            "%.2f",
                            item.price
                        )
                    }",

                    onAdd = {
                        onAddToCart(item)
                    }
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),

            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Button(
                onClick = onBack,

                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),

                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4DB69E)
                ),

                shape = RoundedCornerShape(25.dp)
            ) {

                Text(
                    "REGRESAR",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onGoToCart,

                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),

                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4DB69E)
                ),

                shape = RoundedCornerShape(25.dp)
            ) {

                Text(
                    "IR A CARRITO",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ================= CARRITO =================

@Composable
fun ClientCartScreen(
    cartItems: List<CartItem>,
    customerName: String,
    tableNumber: String,
    onBack: () -> Unit,
    onUpdateQuantity: (MenuItem, Int) -> Unit,
    onOrder: () -> Unit
) {

    var orderDone by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFBF541F))
            .padding(30.dp)
            .statusBarsPadding(),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            "TU CARRITO",
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (cartItems.isEmpty()) {

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {

                Text(
                    "EL CARRITO ESTÁ VACÍO",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

        } else {

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                items(
                    items = cartItems
                ) { item ->

                    CartItemVisual(
                        name = item.item.name,
                        price = "$ ${item.item.price}",
                        quantity = item.quantity.toString(),

                        onPlus = {
                            onUpdateQuantity(item.item, 1)
                        },

                        onMinus = {
                            onUpdateQuantity(item.item, -1)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            "CLIENTE: $customerName",
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Text(
            "MESA: $tableNumber",
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                orderDone = true
                onOrder()
            },

            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),

            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4DB69E)
            ),

            shape = RoundedCornerShape(27.dp)
        ) {

            Text(
                "HACER ORDEN",
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onBack,

            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),

            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4DB69E)
            ),

            shape = RoundedCornerShape(27.dp)
        ) {

            Text(
                "REGRESAR",
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
        }

        if (orderDone) {

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                "ORDEN ENVIADA ✔",
                color = Color.Green,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ================= MENU CARD =================

@Composable
fun MenuCardVisual(
    name: String,
    price: String,
    onAdd: () -> Unit
) {

    var added by remember {
        mutableStateOf(false)
    }

    Card(
        modifier = Modifier.aspectRatio(0.85f),

        shape = RoundedCornerShape(24.dp),

        colors = CardDefaults.cardColors(
            containerColor =
                if (added)
                    Color(0xFFF5DED6)
                else
                    Color.White
        )
    ) {

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {

            Column {

                Text(
                    name,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Text(
                    price,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (added) {

                    Text(
                        "AGREGADO ✔",
                        color = Color(0xFF1B5E20),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            IconButton(
                onClick = {

                    onAdd()
                    added = true

                },

                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(32.dp)
                    .background(

                        if (added)
                            Color(0xFF2E7D32)
                        else
                            Color(0xFF4DB69E),

                        CircleShape
                    )
            ) {

                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        }
    }
}

// ================= ITEM CARRITO =================

@Composable
fun CartItemVisual(
    name: String,
    price: String,
    quantity: String,
    onPlus: () -> Unit,
    onMinus: () -> Unit
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),

        shape = RoundedCornerShape(20.dp),

        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFE0E0E0)
        )
    ) {

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),

            verticalAlignment = Alignment.CenterVertically

        ) {

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    name,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Text(
                    price,
                    color = Color.Black
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    "CANT: $quantity",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {

                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .background(
                                Color(0xFFF9B057),
                                CircleShape
                            ),

                        contentAlignment = Alignment.Center
                    ) {

                        TextButton(
                            onClick = onPlus,

                            contentPadding = PaddingValues(0.dp),

                            modifier = Modifier.size(22.dp)
                        ) {

                            Text(
                                "+",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .background(
                                Color(0xFFF9B057),
                                CircleShape
                            ),

                        contentAlignment = Alignment.Center
                    ) {

                        TextButton(
                            onClick = onMinus,

                            contentPadding = PaddingValues(0.dp),

                            modifier = Modifier.size(22.dp)
                        ) {

                            Text(
                                "-",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }
    }
}

// ================= PEDIDOS ACTIVOS =================

@Composable
fun ActiveOrdersScreen(
    orders: List<Order>,
    onDeleteOrder: (Order) -> Unit,
    onLogout: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF6D3311))
            .padding(16.dp)
            .statusBarsPadding(),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            "PEDIDOS ACTIVOS",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (orders.isEmpty()) {

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {

                Text(
                    "NO HAY PEDIDOS",
                    color = Color.White
                )
            }

        } else {

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                items(
                    items = orders
                ) { order ->

                    Card(
                        modifier = Modifier.fillMaxWidth(),

                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFF7C284)
                        ),

                        shape = RoundedCornerShape(20.dp)
                    ) {

                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {

                            Text(
                                "CLIENTE: ${order.customerName}",
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                "MESA: ${order.tableNumber}",
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            order.items.forEach {

                                Text(
                                    "${it.quantity} x ${it.item.name}"
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                "TOTAL: $ ${
                                    String.format(
                                        Locale.US,
                                        "%.2f",
                                        order.total
                                    )
                                }",

                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    onDeleteOrder(order)
                                },

                                modifier = Modifier.fillMaxWidth(),

                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF4DB69E)
                                ),

                                shape = RoundedCornerShape(16.dp)
                            ) {

                                Text(
                                    "FINALIZAR PEDIDO",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = onLogout,

            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),

            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4DB69E)
            ),

            shape = RoundedCornerShape(25.dp)
        ) {

            Text(
                "CERRAR SESIÓN",
                color = Color.Black,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

